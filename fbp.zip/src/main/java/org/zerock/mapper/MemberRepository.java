package org.zerock.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.zerock.domain.MemberVO;

@Mapper
public interface MemberRepository {
	public MemberVO getSelectOne(MemberVO memberVO)throws Exception;
}
