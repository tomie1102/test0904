package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.Criteria;
import org.zerock.domain.PlayerVO;

public interface PlayerMapper {
	public List<PlayerVO> getList();
	
	public List<PlayerVO> getListWithPaging(Criteria cri);
	
	public PlayerVO read(Long p_no);
	
	public void insert(PlayerVO player);
	
	public void insertSelectKey(PlayerVO player);
	
	public int delete(Long p_no);
	
	public int update(PlayerVO player);
}
