package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.PlayerAttachVO;

	public interface PlayerAttachMapper {
	
	public void insert(PlayerAttachVO vo);

	public void delete(String uuid);

	public List<PlayerAttachVO> findByP_no(Long p_no);

	public void deleteAll(Long p_no);

	public List<PlayerAttachVO> getOldFiles();

}
