package org.zerock.domain;

import java.util.List;

import lombok.Data;

@Data
public class PlayerVO {
	private Long p_no;
	private String p_name;
	private int p_stat;
	private int p_pac;
	private int p_sho;
	private int p_pas;
	private int p_dri;
	private int p_def;
	private int p_phy;
	private String p_fileName;
	
	private List<PlayerAttachVO> attachList;

}
