package org.zerock.domain;

import lombok.Data;

@Data
public class MemberVO {
	
	private Long m_no;
	private String m_name;
	private String m_id;
	private String m_pw;
	private String m_tel;
	private String m_address;
	

}
