package org.zerock.domain;

import lombok.Data;

@Data
public class PlayerAttachVO {

	private String uuid;
	private String uploadPath;
	private String fileName;
	private boolean fileType;
	
	private Long p_no;
}
