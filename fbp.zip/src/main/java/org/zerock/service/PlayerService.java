package org.zerock.service;

import java.util.List;

import org.zerock.domain.Criteria;
import org.zerock.domain.PlayerAttachVO;
import org.zerock.domain.PlayerVO;

public interface PlayerService {

	public void register(PlayerVO player);

	public PlayerVO get(Long p_no);

	public boolean modify(PlayerVO player);

	public boolean remove(Long p_no);

	public List<PlayerVO> getList();

//	public List<PlayerVO> getList(Criteria cri);

	public List<PlayerAttachVO> getAttachList(Long p_no);
}
