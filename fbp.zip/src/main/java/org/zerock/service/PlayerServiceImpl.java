package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.Criteria;
import org.zerock.domain.PlayerAttachVO;
import org.zerock.domain.PlayerVO;
import org.zerock.mapper.PlayerAttachMapper;
import org.zerock.mapper.PlayerMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class PlayerServiceImpl implements PlayerService{
	
	@Setter(onMethod_= @Autowired)
	private PlayerMapper mapper;
	
	@Setter(onMethod_= @Autowired)
	private PlayerAttachMapper attachMapper;
	
	@Transactional
	@Override
	public void register(PlayerVO player) {
		log.info("register....."+player);
		mapper.insertSelectKey(player);
		
		if(player.getAttachList() == null || player.getAttachList().size() <= 0 ) {
			return;
		}
		
		player.getAttachList().forEach(attach -> {
			attach.setP_no(player.getP_no());
			attachMapper.insert(attach);
		});
		
	}

	@Override
	public PlayerVO get(Long p_no) {
		log.info("get■■■■■ " + p_no);
		
		return mapper.read(p_no);
	}

	@Override
	public List<PlayerVO> getList() {
		return mapper.getList();
	}

//	@Override
//	public List<PlayerVO> getList(Criteria cri) {
//		log.info("get List with criteria : "+cri);
//		return mapper.getListWithPaging(cri);
//	}
	
	@Override
	public List<PlayerAttachVO> getAttachList(Long p_no) {

		log.info("get Attach list by p_no" + p_no);

		return attachMapper.findByP_no(p_no);
	}
	
	@Override
	public boolean modify(PlayerVO player) {
	log.info("modify■■■■■ "+player);
	return mapper.update(player) == 1;
	}

	@Override
	public boolean remove(Long p_no) {
	log.info("remove■■■■■ "+p_no);
	return mapper.delete(p_no)==1;
	}
	
//	@Transactional
//	@Override
//	public boolean remove(Long p_no) {
//		log.info("remove...."+p_no);
//		
//		attachMapper.deleteAll(p_no);
//		
//		return mapper.delete(p_no) == 1;
//	}
//	
//	@Transactional
//	@Override
//	public boolean modify(PlayerVO player) {
//		
//		log.info("modify......"+player);
//		
//		attachMapper.deleteAll(player.getP_no());
//		
//		boolean modifyResult = mapper.update(player) == 1;
//		
//		if (modifyResult && player.getAttachList() != 
//				null && player.getAttachList().size() >0) {
//			
//			player.getAttachList().forEach(attach -> {
//				attach.setP_no(player.getP_no());
//				attachMapper.insert(attach);
//			});
//		}
//		return modifyResult;
//	}

}
